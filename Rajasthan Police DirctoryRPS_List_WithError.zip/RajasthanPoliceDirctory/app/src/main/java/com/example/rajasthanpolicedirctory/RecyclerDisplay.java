package com.example.rajasthanpolicedirctory;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class RecyclerDisplay extends AppCompatActivity {

    DirSearch d1 = new DirSearch(1,"Akshay Dadhich","773771042");
    DirSearch d2 = new DirSearch(2,"Akshay Dadhich","773771042");
    DirSearch d3 = new DirSearch(3,"Akshay Dadhich","773771042");
    DirSearch d4 = new DirSearch(4,"Akshay Dadhich","773771042");
    DirSearch d5 = new DirSearch(5,"Akshay Dadhich","773771042");
    DirSearch d6 = new DirSearch(6,"Akshay Dadhich","773771042");
    DirSearch d7 = new DirSearch(7,"Akshay Dadhich","773771042");
    DirSearch d8 = new DirSearch(8,"Akshay Dadhich","773771042");
    DirSearch d9 = new DirSearch(9,"Akshay Dadhich","773771042");
    DirSearch d10 = new DirSearch(10,"Akshay Dadhich","773771042");
    DirSearch d11 = new DirSearch(11,"Akshay Dadhich","773771042");
    DirSearch d12 = new DirSearch(12,"Akshay Dadhich","773771042");
    DirSearch d13 = new DirSearch(13,"Akshay Dadhich","773771042");
    DirSearch d14 = new DirSearch(14,"Akshay Dadhich","773771042");
    DirSearch d15 = new DirSearch(15,"Akshay Dadhich","773771042");
    DirSearch d16 = new DirSearch(16,"Akshay Dadhich","773771042");
    DirSearch d17 = new DirSearch(17,"Akshay Dadhich","773771042");
    DirSearch d18 = new DirSearch(18,"Akshay Dadhich","773771042");
    DirSearch d19 = new DirSearch(19,"Akshay Dadhich","773771042");
    DirSearch d20 = new DirSearch(20,"Akshay Dadhich","773771042");
    DirSearch[] dirSearch = {d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,d11,d12,d13,d14,d15,d16,d17,d18,d19,d20};
    RecyclerView recyclerView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_display);

        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        CustomAdapter c = new CustomAdapter(dirSearch);
        recyclerView.setAdapter(c);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }
    //When clicked of view
    public void ShowInfo(View view) {
        Intent intent = new Intent(this, EmployeeInfo.class);
        //intent.putExtra(EXTRA_MESSAGE, "Name");
        startActivity(intent);
    }
}