package com.example.rajasthanpolicedirctory;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    public static final String EXTRA_MESSAGE = "com.example.rajasthanpolicedirctory.MESSAGE";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
//        getSupportActionBar().hide();
    }
        public void sendMessage(View view) {
            Intent intent = new Intent(this, SearchDirectory.class);
            //intent.putExtra(EXTRA_MESSAGE, "Name");
            startActivity(intent);
        }

    public void sendDeptOrders(View view) {
        Intent intent = new Intent(this, DeptOrders.class);
        //intent.putExtra(EXTRA_MESSAGE, "Name");
        startActivity(intent);
    }
    public void sendControlRooms(View view) {
        Intent intent = new Intent(this, ControlRooms.class);
        //intent.putExtra(EXTRA_MESSAGE, "Name");
        startActivity(intent);
    }
    public void sendAllRPS(View view) {
        Intent intent = new Intent(this, AllRPS.class);
        //intent.putExtra(EXTRA_MESSAGE, "Name");
        startActivity(intent);
    }

}