package com.example.rajasthanpolicedirctory;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;

public class ControlRooms extends AppCompatActivity {
    DirSearch d1 = new DirSearch(1,"AJMER","1452629166");
    DirSearch d2 = new DirSearch(2,"ALWAR","1442338200");
    DirSearch d3 = new DirSearch(3,"BANSWARA","2962241100");
    DirSearch d4 = new DirSearch(4,"BARAN","7453230383");
    DirSearch d5 = new DirSearch(5,"BARMER","2982221822");
    DirSearch d6 = new DirSearch(6,"BHARATPUR","5644222570");
    DirSearch d7 = new DirSearch(7,"BHILWARA","1482232011");
    DirSearch d8 = new DirSearch(8,"BIKANER","1512226123");
    DirSearch d9 = new DirSearch(9,"BUNDI","7472443901");
    DirSearch d10 = new DirSearch(10,"CHITTORGARH","1472240088");
    DirSearch d11 = new DirSearch(11,"CHURU","1562252023");
    DirSearch d12 = new DirSearch(12,"DAUSA","1427230333");
    DirSearch d13 = new DirSearch(13,"DHOLPUR","5642220697");
    DirSearch d14 = new DirSearch(14,"DUNGARPUR","2964230344");
    DirSearch d15 = new DirSearch(15,"GRP AJMER","1452429451");
    DirSearch d16 = new DirSearch(16,"GRP JODHPUR","2912650745");
    DirSearch d17 = new DirSearch(17,"HANUMANGARH","1552261105");
    DirSearch d18 = new DirSearch(18,"JAIPUR COMMISSIONERATE","1412574456");
    DirSearch d19 = new DirSearch(19,"JAIPUR RURAL","N/A");
    DirSearch d20 = new DirSearch(20,"JAISALMER","292252100");
    DirSearch d21 = new DirSearch(20,"JALORE","2973224031");
    DirSearch d22 = new DirSearch(20,"JHALAWAR","7432231565");
    DirSearch d23 = new DirSearch(20,"JHUNJHUNU","1592236700");
    DirSearch d24 = new DirSearch(20,"JODHPUR COMMISSIONERATE","2912650777");
    DirSearch d25 = new DirSearch(20,"JODHPUR RURAL","2912650888");
    DirSearch d26 = new DirSearch(20,"KARAULI","7464220477");
    DirSearch d27 = new DirSearch(20,"KOTA CITY","7442350778");
    DirSearch d28 = new DirSearch(20,"KOTA RURAL","7442350888");
    DirSearch d29 = new DirSearch(20,"NAGAUR","1582243247");
    DirSearch d30 = new DirSearch(20,"PALI","2932251545");
    DirSearch d31 = new DirSearch(20,"PRATAPGARH","1478220065");
    DirSearch d32 = new DirSearch(20,"RAJSAMAND","2952220712");
    DirSearch d33 = new DirSearch(20,"SAWAI MADHOPUR","7462222999");
    DirSearch d34 = new DirSearch(20,"SIKAR","1572270037");
    DirSearch d35 = new DirSearch(20,"SIROHI","2972222100");
    DirSearch d36 = new DirSearch(20,"SRIGANGANAGAR","2972222100");
    DirSearch d37 = new DirSearch(20,"TONK","2972222100");
    DirSearch d38 = new DirSearch(20,"UDAIPUR","2972222100");
    DirSearch[] dirSearch = {d1,d2,d3,d4,d5,d6,d7,d8,d9,d10,d11,d12,d13,d14,d15,d16,d17,d18,d19,d20,d21,d22,d23,d24,d25,d26,d27,d28,d29,d30,d31,d32,d33,d34,d35,d36,d37,d38};
    RecyclerView recyclerView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recycler_display);

        recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        CustomAdapter c = new CustomAdapter(dirSearch);
        recyclerView.setAdapter(c);
        recyclerView.addItemDecoration(new DividerItemDecoration(this, DividerItemDecoration.VERTICAL));
    }
//    //When clicked of view
//    public void ShowInfo(View view) {
//        Intent intent = new Intent(this, EmployeeInfo.class);
//        //intent.putExtra(EXTRA_MESSAGE, "Name");
//        startActivity(intent);
//    }
}