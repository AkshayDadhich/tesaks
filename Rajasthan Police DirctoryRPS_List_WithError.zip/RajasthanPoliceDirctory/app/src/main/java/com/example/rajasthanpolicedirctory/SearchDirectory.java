package com.example.rajasthanpolicedirctory;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;

public class SearchDirectory extends AppCompatActivity implements
        AdapterView.OnItemSelectedListener {
    public static final String EXTRA_MESSAGE = "com.example.rajasthanpolicedirctory.MESSAGE";
    String[] district = {"District", "Ajmer", "Alwar", "Banswara", "Baran", "Barmer", "Bharatpur", "Bhilwara", "Bikaner", "Bundi", "Chittorgarh", "Churu", "Dausa", "Dholpur", "Dungarpur","Hanumangarh","Jaipur","Jaisalmer","Jalor","Jhalawar","Jhunjhunu","Jodhpur","Karauli","Kota","Nagaur","Pali","Pratapgarh","Rajsamand","Sawai Madhopur","Sikar","Sirohi","Sri Ganganagar","Tonk","Udaipur" };
    TextView designation;
    boolean[] selectedDesignation;
    ArrayList<Integer> langList = new ArrayList<>();
    String[] DesignationArray = {"IPS", "RPS", "Circle Inspector", "Senior Inspector", "Inspector", "Head Constable", "Constable"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search_directory);
        Spinner spin = findViewById(R.id.district);
        spin.setOnItemSelectedListener(this);

        //Creating the ArrayAdapter instance having the district list
        ArrayAdapter aa = new ArrayAdapter(this, android.R.layout.simple_spinner_item, district);
        aa.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //Setting the ArrayAdapter data on the Spinner
        spin.setAdapter(aa);

        // assign variable
        designation = findViewById(R.id.designation);

        // initialize selected language array
        selectedDesignation = new boolean[DesignationArray.length];

        designation.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {

            // Initialize alert dialog
            AlertDialog.Builder builder = new AlertDialog.Builder(SearchDirectory.this);

            // set title
            builder.setTitle("Select");

            // set dialog non cancelable
            builder.setCancelable(false);

            builder.setMultiChoiceItems(DesignationArray, selectedDesignation, new DialogInterface.OnMultiChoiceClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i, boolean b) {
            // check condition
            if (b) {
                // when checkbox selected
                // Add position  in lang list
                langList.add(i);
                // Sort array list
                Collections.sort(langList);
            } else {
                // when checkbox unselected
                // Remove position from langList
                langList.remove(Integer.valueOf(i));
            }
                    }
                });

                builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
            // Initialize string builder
            StringBuilder stringBuilder = new StringBuilder();
            // use for loop
            for (int j = 0; j < langList.size(); j++) {
                // concat array value
                stringBuilder.append(DesignationArray[langList.get(j)]);
                // check condition
                if (j != langList.size() - 1) {
                    // When j value  not equal
                    // to lang list size - 1
                    // add comma
                    stringBuilder.append(", ");
                }
            }
            // set text on textView
            designation.setText(stringBuilder.toString());
                    }
                });

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
            // dismiss dialog
            dialogInterface.dismiss();
                    }
                });
                builder.setNeutralButton("Clear All", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
            // use for loop
            for (int j = 0; j < selectedDesignation.length; j++) {
                // remove all selection
                selectedDesignation[j] = false;
                // clear language list
                langList.clear();
                // clear text view value
                designation.setText("");
            }
                    }
                });
                // show dialog
                builder.show();
            }
                    });
                }

            @Override
            public void onItemSelected(AdapterView<?> arg0, View arg1, int position, long id) {
                Toast.makeText(getApplicationContext(), district[position], Toast.LENGTH_LONG).show();
            }

        @Override
        public void onNothingSelected(AdapterView<?> arg0) {
            // TODO Auto-generated method stub
        }
        //When clicked of search
        public void sendMessage(View view) {
            Intent intent = new Intent(this, RecyclerDisplay.class);
            //intent.putExtra(EXTRA_MESSAGE, "Name");
            startActivity(intent);
        }
}

