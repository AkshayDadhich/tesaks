package com.example.rajasthanpolicedirctory;

public class DirSearch {
    public int sno;
    public String phoneNumber;
    public String name;

    public DirSearch(int sno, String name, String phoneNumber){
        this.sno = sno;
        this.phoneNumber = phoneNumber;
        this.name = name;
    }
}
